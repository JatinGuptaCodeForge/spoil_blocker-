document.getElementById('submitBtn').addEventListener('click', () => {
  const textAreaContent = document.getElementById('textArea').value;
  console.log('Submitted Text:', textAreaContent);
  alert('Submitted: ' + textAreaContent);
});

document.getElementById('copyBtn').addEventListener('click', () => {
  const textArea = document.getElementById('textArea');
  textArea.select();
  document.execCommand('copy');
  alert('Text copied to clipboard');
});
